// Listen for messages from the content script
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === "openNewTab") {
    // Open a new tab with the instructions page URL
    chrome.tabs.create({ url: "http://localhost:8000/extension1_frontPage/instructions.html" });
  }
});